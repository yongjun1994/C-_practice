﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static PuyoPuyo.Form1.PuyoOperation;
using static System.Net.Mime.MediaTypeNames;

namespace PuyoPuyo
{
    public partial class Form1 : Form
    {
        public class PuyoOperation
        {
            const int FIELD_ROW = 10, FIELD_COL = 6;
            const int MIN_PUYO = 1, MAX_PUYO = 3;
            const int FINISH_LINE = 3;

            public int[,] arr = new int[FIELD_ROW, FIELD_COL];
            private struct GenPuyo
            {
                public int puyo1;
                public int puyo1X;
                public int puyo1Y;
                public int puyo1DropX;
                public int puyo1DropY;
                public int puyo2;
                public int puyo2X;
                public int puyo2Y;
                public int puyo2DropX;
                public int puyo2DropY;
            }

            GenPuyo puyo = new GenPuyo();

            public int GetPuyo1DropX()
            { 
                return puyo.puyo1DropX;
            }
            public int GetPuyo1DropY()
            {
                return puyo.puyo1DropY;
            }
            public int GetPuyo2DropX()
            {
                return puyo.puyo2DropX;
            }
            public int GetPuyo2DropY()
            {
                return puyo.puyo2DropY;
            }
            public void FieldInit()
            {
                for (int i = 0; i < FIELD_ROW; i++)
                {
                    for (int j = 0; j < FIELD_COL; j++)
                    {
                        arr[i, j] = 0;
                    }
                }
            }

            public void FieldPrint(TextBox tb)
            {
                tb.Clear();   //tb.Text = "";

                for (int i = 0; i < arr.GetLength(0); i++)
                {
                    for (int j = 0; j < arr.GetLength(1); j++)
                    {
                        if (arr[i, j] > 0)
                        {
                            tb.Text += arr[i, j];
                        }
                        else
                        {
                            tb.Text += " ";
                        }
                    }

                    tb.Text += Environment.NewLine;
                }

                // MessageBox.Show($"{puyo.puyo1Y}, {puyo.puyo1X}, {puyo.puyo2Y}, {puyo.puyo2X}");
            }

            public void CreatePuyos()
            {
                Random rand = new Random();

                puyo.puyo1 = rand.Next(MIN_PUYO, MAX_PUYO + 1);
                puyo.puyo2 = rand.Next(MIN_PUYO, MAX_PUYO + 1);

                puyo.puyo1X = 2;
                puyo.puyo1Y = 1;
                puyo.puyo2X = 3;
                puyo.puyo2Y = 1;

                arr[puyo.puyo1Y, puyo.puyo1X] = puyo.puyo1;
                arr[puyo.puyo2Y, puyo.puyo2X] = puyo.puyo2;
            }

            public void MoveLeft()
            {
                if (puyo.puyo1X > 0 && puyo.puyo2X > 0)
                {
                    arr[puyo.puyo1Y, puyo.puyo1X] = 0;
                    arr[puyo.puyo2Y, puyo.puyo2X] = 0;

                    puyo.puyo1X -= 1;
                    puyo.puyo2X -= 1;
                    arr[puyo.puyo1Y, puyo.puyo1X] = puyo.puyo1;
                    arr[puyo.puyo2Y, puyo.puyo2X] = puyo.puyo2;
                }
            }

            public void MoveRight()
            {
                if (puyo.puyo1X < FIELD_COL - 1 && puyo.puyo2X < FIELD_COL - 1)
                {
                    arr[puyo.puyo1Y, puyo.puyo1X] = 0;
                    arr[puyo.puyo2Y, puyo.puyo2X] = 0;

                    puyo.puyo1X += 1;
                    puyo.puyo2X += 1;
                    arr[puyo.puyo1Y, puyo.puyo1X] = puyo.puyo1;
                    arr[puyo.puyo2Y, puyo.puyo2X] = puyo.puyo2;
                }
            }

            public bool MoveDown()
            {
                int index1 = -1, index2 = -1;

                if (puyo.puyo1X == puyo.puyo2X)
                {
                    for (int i = FIELD_ROW - 1; i >= FINISH_LINE; i--)
                    {
                        if (arr[i, puyo.puyo1X] <= 0)
                        {
                            index1 = i;
                            break;
                        }
                    }

                    if (index1 <= FINISH_LINE)
                    {
                        MessageBox.Show("거기에는 놓을 수 없습니다1");
                        return false;
                    }

                    index2 = index1 - 1;
                    if (puyo.puyo1Y > puyo.puyo2Y)
                    {
                        arr[index1, puyo.puyo1X] = puyo.puyo1;
                        arr[index2, puyo.puyo2X] = puyo.puyo2;
                        puyo.puyo1DropX = puyo.puyo1X;
                        puyo.puyo1DropY = index1;
                        puyo.puyo2DropX = puyo.puyo2X;
                        puyo.puyo2DropY = index2;
                    }
                    else
                    {
                        arr[index1, puyo.puyo2X] = puyo.puyo2;
                        arr[index2, puyo.puyo1X] = puyo.puyo1;
                        puyo.puyo1DropX = puyo.puyo1X;
                        puyo.puyo1DropY = index2;
                        puyo.puyo2DropX = puyo.puyo2X;
                        puyo.puyo2DropY = index1;
                    }

                    arr[puyo.puyo1Y, puyo.puyo1X] = 0;
                    arr[puyo.puyo2Y, puyo.puyo2X] = 0;
                }
                else
                {
                    for (int i = FIELD_ROW - 1; i >= FINISH_LINE; i--)
                    {
                        if (arr[i, puyo.puyo1X] <= 0 && index1 < 0)
                        {
                            index1 = i;
                        }
                        if (arr[i, puyo.puyo2X] <= 0 && index2 < 0)
                        {
                            index2 = i;
                        }
                        if (index1 >= 0 && index2 >= 0)
                        {
                            break;
                        }
                    }

                    if (index1 < FINISH_LINE || index2 < FINISH_LINE)
                    {
                        MessageBox.Show("거기에는 놓을 수 없습니다2");
                        return false;
                    }

                    arr[index1, puyo.puyo1X] = puyo.puyo1;
                    arr[index2, puyo.puyo2X] = puyo.puyo2;
                    puyo.puyo1DropX = puyo.puyo1X;
                    puyo.puyo1DropY = index1;
                    puyo.puyo2DropX = puyo.puyo2X;
                    puyo.puyo2DropY = index2;
                    arr[puyo.puyo1Y, puyo.puyo1X] = 0;
                    arr[puyo.puyo2Y, puyo.puyo2X] = 0;
                }

                return true;
            }

            public void Rotate()
            {
                if (puyo.puyo1Y == puyo.puyo2Y && puyo.puyo1X < puyo.puyo2X)
                {
                    arr[puyo.puyo2Y + 1, puyo.puyo2X - 1] = puyo.puyo2;
                    arr[puyo.puyo2Y, puyo.puyo2X] = 0;
                    puyo.puyo2Y++;
                    puyo.puyo2X--;
                }
                else if (puyo.puyo1Y == puyo.puyo2Y && puyo.puyo1X > puyo.puyo2X)
                {
                    arr[puyo.puyo2Y - 1, puyo.puyo2X + 1] = puyo.puyo2;
                    arr[puyo.puyo2Y, puyo.puyo2X] = 0;
                    puyo.puyo2Y--;
                    puyo.puyo2X++;
                }
                else if (puyo.puyo1X == puyo.puyo2X && puyo.puyo2Y > puyo.puyo1Y)
                {
                    if (puyo.puyo2X - 1 >= 0)
                    {
                        arr[puyo.puyo2Y - 1, puyo.puyo2X - 1] = puyo.puyo2;
                        arr[puyo.puyo2Y, puyo.puyo2X] = 0;
                        puyo.puyo2Y--;
                        puyo.puyo2X--;
                    }
                }
                else if (puyo.puyo1X == puyo.puyo2X && puyo.puyo1Y > puyo.puyo2Y)
                {
                    if (puyo.puyo2X + 1 < FIELD_COL)
                    {
                        arr[puyo.puyo2Y + 1, puyo.puyo2X + 1] = puyo.puyo2;
                        arr[puyo.puyo2Y, puyo.puyo2X] = 0;
                        puyo.puyo2Y++;
                        puyo.puyo2X++;
                    }
                }
            }

            public bool IsGameOver()
            {
                for (int i = 0; i < FIELD_COL; i++)
                {
                    if (arr[FINISH_LINE, i] <= 0 && arr[FINISH_LINE + 1, i] <= 0)
                    {
                        return false;
                    }
                }
                for (int i = 0; i < FIELD_COL-1; i++)
                {
                    if (arr[FINISH_LINE, i] <= 0 && arr[FINISH_LINE, i + 1] <= 0)
                    {
                        return false;
                    }
                }

                return true;
            }

            public void EvaporatePuyo(List<(int, int)> _connected)
            {
                //MessageBox.Show($"count {_connected.Count}");
                foreach (var (i, j) in _connected)
                {
                    //MessageBox.Show($"{i},{j}");
                    arr[i, j] = 0;
                }
            }

            public void PulldownEmpties()
            {
                for (int i = 0; i < FIELD_COL; i++)
                {
                    for (int j = FIELD_ROW - 1; j >= FINISH_LINE + 1; j--)
                    {
                        //MessageBox.Show($"{i},{j}");
                        if (arr[j, i] == 0)
                        {
                            int posJ = j;
                            for (int k = posJ - 1; k >= FINISH_LINE; k--)
                            {
                                if (arr[k, i] > 0)
                                {
                                    arr[posJ,i] = arr[k,i];
                                    arr[k, i] = 0;
                                    posJ--;
                                }
                            }

                            break;
                        }
                    }
                }
            }
        }

        public class IndexOperation
        {
            // 반환값: 같은 값을 가진 인접 인덱스들의 리스트(List<(int, int)>)
            public List<(int, int)> FindConnectedIndices(int[,] arr, int i, int j)
            {
                int rowCount = arr.GetLength(0); // 10
                int colCount = arr.GetLength(1); // 6
                int targetValue = arr[i, j];

                // 방문 여부 체크용
                bool[,] visited = new bool[rowCount, colCount];
                List<(int, int)> result = new List<(int, int)>();
                Queue<(int, int)> queue = new Queue<(int, int)>();

                int[] dx = { -1, 1, 0, 0 }; // 상, 하, 좌, 우
                int[] dy = { 0, 0, -1, 1 };

                if (targetValue == 0)
                {
                    return result;
                }

                // BFS 시작
                queue.Enqueue((i, j));
                visited[i, j] = true;

                while (queue.Count > 0)
                {
                    var (x, y) = queue.Dequeue();
                    result.Add((x, y));

                    for (int d = 0; d < 4; d++)
                    {
                        int nx = x + dx[d];
                        int ny = y + dy[d];

                        // 배열 범위 체크
                        if (nx >= 0 && nx < rowCount && ny >= 0 && ny < colCount)
                        {
                            if (!visited[nx, ny] && arr[nx, ny] == targetValue)
                            {
                                queue.Enqueue((nx, ny));
                                visited[nx, ny] = true;
                            }
                        }
                    }
                }

                return result;
            }
        }

        PuyoOperation puyoOp = new PuyoOperation();

        public Form1()
        {
            InitializeComponent();

            puyoOp.FieldInit();
            puyoOp.CreatePuyos();
            puyoOp.FieldPrint(textBox1);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // 
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            puyoOp.MoveLeft();
            puyoOp.FieldPrint(textBox1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            puyoOp.MoveRight();
            puyoOp.FieldPrint(textBox1);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            puyoOp.Rotate();
            puyoOp.FieldPrint(textBox1);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (puyoOp.MoveDown())
            {
                puyoOp.FieldPrint(textBox1);
                System.Windows.Forms.Application.DoEvents();
                System.Threading.Thread.Sleep(500);
                if (puyoOp.IsGameOver())
                {
                    MessageBox.Show("Game Over");
                }
                else
                {
                    bool evaporated = false;

                    IndexOperation indices = new IndexOperation();
                    List<(int,int)> connected1 = indices.FindConnectedIndices(puyoOp.arr, puyoOp.GetPuyo1DropY(), puyoOp.GetPuyo1DropX());
                    
                    if (connected1.Count >= 4)
                    {
                        puyoOp.EvaporatePuyo(connected1);
                        System.Windows.Forms.Application.DoEvents();
                        System.Threading.Thread.Sleep(500);
                        evaporated = true;
                    }
                    List<(int, int)> connected2 = indices.FindConnectedIndices(puyoOp.arr, puyoOp.GetPuyo2DropY(), puyoOp.GetPuyo2DropX());
                    if (connected2.Count >= 4)
                    {
                        puyoOp.EvaporatePuyo(connected2);
                        System.Windows.Forms.Application.DoEvents();
                        System.Threading.Thread.Sleep(500);
                        evaporated = true;
                    }

                    if (evaporated)
                    {
                        puyoOp.FieldPrint(textBox1);
                        System.Windows.Forms.Application.DoEvents();
                        System.Threading.Thread.Sleep(200);
                        puyoOp.PulldownEmpties();
                        System.Windows.Forms.Application.DoEvents();
                        System.Threading.Thread.Sleep(200);
                        puyoOp.FieldPrint(textBox1);
                    }

                    puyoOp.CreatePuyos();
                    puyoOp.FieldPrint(textBox1);
                }
            }
        }
    }
}
